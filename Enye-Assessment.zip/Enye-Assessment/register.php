<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Basic Validation
    if (strlen($password) < 6) {
        $error = "Password must be at least 6 characters.";
    } else {
        // Password Hashing for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if username exists using Prepared Statement
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $hashed_password);

        if ($stmt->execute()) {
            echo "<script>alert('Registration Successful!'); window.location='login.php';</script>";
        } else {
            $error = "Username already taken.";
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head><title>Register</title></head>
<body>
    <h2>Create Account</h2>
    <?php if(isset($error)) echo "<p style='color:red'>$error</p>"; ?>
    <form method="POST">
        <input type="text" name="username" placeholder="Choose Username" required><br><br>
        <input type="password" name="password" placeholder="Choose Password (min 6 chars)" required><br><br>
        <button type="submit">Register Now</button>
    </form>
    <br>
    <a href="login.php">Back to Login</a>
</body>
</html>
