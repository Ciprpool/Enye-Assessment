<?php
session_start();
require 'db.php';
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit(); }

$id = $_GET['id'];
$user_id = $_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM tasks WHERE id = ? AND user_id = ?");
$stmt->bind_param("ii", $id, $user_id);
$stmt->execute();
$task = $stmt->get_result()->fetch_assoc();

if (!$task) { die("Task not found or unauthorized."); }

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $title = $_POST['title'];
    $description = $_POST['description'];
    $status = $_POST['status'];

    $update = $conn->prepare("UPDATE tasks SET title=?, description=?, status=? WHERE id=? AND user_id=?");
    $update->bind_param("sssii", $title, $description, $status, $id, $user_id);
    $update->execute();
    header("Location: dashboard.php");
}
?>
<h2>Edit Task</h2>
<form method="POST">
    <input type="text" name="title" value="<?php echo $task['title']; ?>" required><br><br>
    <textarea name="description"><?php echo $task['description']; ?></textarea><br><br>
    <select name="status">
        <option value="Pending" <?php if($task['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
        <option value="Completed" <?php if($task['status'] == 'Completed') echo 'selected'; ?>>Completed</option>
    </select><br><br>
    <button type="submit">Update Task</button>
    <a href="dashboard.php">Back</a>
</form>